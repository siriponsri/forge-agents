import React, { useEffect, useState } from "react";
import { Download, Play, Square } from "lucide-react";
import {
  command,
  date,
  downloadUrl,
  operationId,
  request,
  scoped,
} from "./api.mjs";
import {
  Badge,
  Collection,
  Empty,
  Field,
  Heading,
  Json,
  Submit,
} from "./ui.jsx";

const initial = {
  schemaVersion: 1,
  title: "",
  language: "th",
  fontFamily: "Tahoma",
  template: { id: "engineering", version: 1 },
  sections: [{ heading: "", text: "" }],
  citations: [],
  inputs: [],
};
export default function Reports({ t, state, projectId, mutate, run, busy }) {
  const reports = scoped(state, "reports", projectId),
    artifacts = scoped(state, "artifacts", projectId),
    documents = scoped(state, "documents", projectId);
  const [selected, setSelected] = useState(""),
    [engines, setEngines] = useState(null),
    [preview, setPreview] = useState(null),
    [configure, setConfigure] = useState(false);
  const record = reports.find((r) => r.id === selected);
  useEffect(() => {
    request("/api/reports/health")
      .then(setEngines)
      .catch((e) => setEngines({ error: e.message }));
  }, []);
  const jobs = scoped(state, "jobs", projectId).filter(
    (j) => j.reportId === record?.id,
  );
  const pdfs = artifacts.filter(
    (a) =>
      a.kind === "pdf" ||
      a.contentType === "application/pdf" ||
      /\.pdf$/i.test(a.filename || a.name || a.path || ""),
  );
  const previewImage=preview&&artifacts.find(a=>a.kind==='png'&&((a.jobId&&a.jobId===preview.jobId)||a.parentArtifactIds?.includes(preview.id)));
  return (
    <>
      <Heading
        title={t("สร้างรายงาน", "Report Studio")}
        description={t(
          "เขียนต้นฉบับรายงานแล้วบันทึก → สร้างไฟล์ DOCX และ PDF จากฉบับเดียวกัน → ตรวจไฟล์แล้วดาวน์โหลด",
          "Save ReportSpec → generate DOCX/PDF from one revision → inspect verified output files.",
        )}
      >
        <button onClick={() => setConfigure(!configure)}>
          {t("ตั้งค่าโปรแกรมสร้างไฟล์และฟอนต์", "Engines & fonts")}
        </button>
      </Heading>
      <div className="engine-strip">
        <span>WordCraft / PdfCraft</span>
        {['wordcraft','pdfcraft'].map(name => <span key={name} role="status">
          {name === 'wordcraft' ? 'WordCraft' : 'PdfCraft'} · {engines?.engines?.[name]?.ready
            ? `${engines.engines[name].identity?.version ?? ''} ${t('พร้อมใช้งาน','Ready')}`
            : engines?.engines?.[name]?.recovery || t('ต้องตั้งค่าก่อนใช้','Check setup')}
        </span>)}
        <button
          onClick={() =>
            run(async () => {
              const h = await request("/api/reports/health");
              setEngines(h);
              return h;
            })
          }
        >
          {t("ตรวจว่าพร้อมใช้", "Check readiness")}
        </button>
        <details>
          <summary>{t("รายละเอียดทางเทคนิค", "Observed readiness")}</summary>
          <Json value={engines || { status: "checking" }} />
        </details>
      </div>
      {configure && (
        <EngineSettings key={JSON.stringify(engines?.config)} health={engines} t={t} run={run} busy={busy} onHealth={setEngines} />
      )}
      <div className="split report-layout">
        <aside className="panel">
          <button onClick={() => setSelected("")}>
            {t("+ ต้นฉบับรายงานใหม่", "+ New report source")}
          </button>
          <Collection
            items={reports}
            selected={selected}
            onSelect={setSelected}
            subtitle={(r) => `r${r.revision} · ${r.spec?.language || "—"}`}
          />
          {!reports.length && (
            <Empty>{t("ยังไม่มีต้นฉบับรายงาน กด + ต้นฉบับรายงานใหม่ เพื่อเริ่ม", "No report sources yet.")}</Empty>
          )}
        </aside>
        <section>
          <SourceEditor
            key={record?.id || "new"}
            {...{ t, record, mutate, busy, artifacts, documents,run,projectId }}
            onSaved={(r) => setSelected(r.entity.id)}
          />
          {record && (
            <section className="panel">
              <div className="record-head">
                <h2>
                  {t("สร้างไฟล์จากต้นฉบับที่บันทึกไว้", "Generate from saved source")}
                </h2>
                <span>r{record.revision}</span>
              </div>
              <p>
                {t(
                  "ระบบจะสร้างไฟล์จากฉบับที่บันทึกล่าสุด ตรวจฟอนต์และการจัดหน้าก่อนดาวน์โหลด",
                  "Generate this saved revision, then review fonts and pagination before downloading.",
                )}
              </p>
              <button
                className="primary"
                disabled={busy}
                onClick={() =>
                  run(() =>
                    request("/api/reports/generate", {
                      operationId: operationId(),
                      projectId,
                      reportId: record.id,
                      expectedRevision: record.revision,
                    }),
                  )
                }
              >
                <Play size={15} />
                {t("สร้าง DOCX และ PDF", "Generate DOCX & PDF")}
              </button>
              {jobs.map((job) => (
                <ReportJob
                  key={job.id}
                  {...{ t, job, run, busy, artifacts, setPreview }}
                />
              ))}
            </section>
          )}
        </section>
      </div>
      <section className="panel">
        <h2>{t("ตรวจและแก้ไฟล์ PDF", "PDF inspection & processing")}</h2>
        {!pdfs.length ? (
          <Empty>
            {t(
              "ยังไม่มีไฟล์ PDF สร้างรายงานก่อน หรืออัปโหลด PDF ในหน้า ไฟล์ผลลัพธ์",
              "Register a verified PDF or generate a report first.",
            )}
          </Empty>
        ) : (
          <>
            <form
              className="inline-form"
              onSubmit={(e) => {
                e.preventDefault();
                const d = new FormData(e.currentTarget);
                run(async () => {
                  const result = await request("/api/reports/pdf-operation", {
                    operationId: operationId(),
                    projectId,
                    artifactId: d.get("artifactId"),
                    expectedRevision: pdfs.find(
                      (a) => a.id === d.get("artifactId"),
                    ).revision,
                    operation: d.get("operation"),
                    degrees: Number(d.get("degrees")),
                    pages: d
                      .get("pages")
                      .split(",")
                      .filter(Boolean)
                      .map(Number),
                    page: Number(d.get("pages").split(",")[0]) || 1,
                  });
                  return result;
                });
              }}
            >
              <Field label="PDF">
                <select name="artifactId">
                  {pdfs.map((a) => (
                    <option value={a.id} key={a.id}>
                      {a.name || a.filename || a.id}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={t("ต้องการทำอะไร", "Operation")}>
                <select name="operation">
                  <option value="inspect">
                    {t("ดูโครงสร้างไฟล์", "Inspect")}
                  </option>
                  <option value="render">
                    {t("ทำภาพตัวอย่างหน้า", "Render pages")}
                  </option>
                  <option value="rotate">{t("หมุนหน้า", "Rotate pages")}</option>
                </select>
              </Field>
              <Field
                label={t(
                  "เลขหน้า",
                  "Pages supported by adapter",
                )}
              >
                <input name="pages" placeholder="1" defaultValue="1" />
              </Field>
              <Field label={t("องศาการหมุน", "Rotation degrees")}>
                <select name="degrees">
                  <option>90</option>
                  <option>180</option>
                  <option>270</option>
                </select>
              </Field>
              <Submit busy={busy}>
                {t("เริ่มทำ", "Run PdfCraft operation")}
              </Submit>
            </form>
            <div className="actions">
              {pdfs.map((a) => (
                <button key={a.id} onClick={() => setPreview(a)}>
                  {t("ดู PDF", "Preview PDF")} · {a.name || a.filename || a.id}
                </button>
              ))}
            </div>
          </>
        )}
      </section>
      <p className="help">
        {t(
          "ยังแปลงไฟล์ XLSX/DOCX เข้ามาไม่ได้ แต่ยังแก้และบันทึกเอกสารใน FORGE ได้ตามปกติ ควรเปิดไฟล์ที่สร้างเพื่อตรวจฟอนต์และการจัดหน้า",
          "Univer Exchange XLSX/DOCX conversion is not enabled. Native editing is independent. Verify fonts and pagination in the actual generated files.",
        )}
      </p>
      {preview && (
        <div className="modal-backdrop">
          <section
            className="modal preview-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="preview-title"
          >
            <div className="record-head">
              <h2 id="preview-title">
                {preview.name || preview.filename || preview.id}
              </h2>
              <div className="actions">
                <a className="button" href={downloadUrl(preview.id)} download>
                  <Download size={14} />
                  {t("ดาวน์โหลด", "Download")}
                </a>
                <button onClick={() => setPreview(null)}>
                  {t("ปิด", "Close")}
                </button>
              </div>
            </div>
            <p className="help">
              {t("ไฟล์ผลลัพธ์ที่บันทึกไว้", "Actual registered artifact")} ·
              SHA256 {preview.sha256 || preview.hash || "—"}
            </p>
            {previewImage?<div className="report-page-preview"><p className="help">{t('หน้าที่ 1 · ภาพจากไฟล์ PDF','Page 1 · rendered from the verified PDF')}</p><img src={downloadUrl(previewImage.id)} alt={t('ภาพหน้ารายงาน','Rendered report page')} style={{display:'block',maxWidth:'100%',height:'auto',margin:'0 auto'}}/></div>:<div className="overview-empty"><p>{t('ยังไม่มีภาพตัวอย่างของ PDF นี้','A rendered preview is not available yet.')}</p><button disabled={busy} onClick={()=>run(()=>request('/api/reports/pdf-operation',{operationId:operationId(),projectId,artifactId:preview.id,expectedRevision:preview.revision,operation:'render',page:1}))}>{t('สร้างภาพตัวอย่าง','Render preview')}</button></div>}
            <a className="button" href={downloadUrl(preview.id)} target="_blank" rel="noreferrer">{t('เปิด PDF แบบเต็ม','Open full PDF')}</a>
          </section>
        </div>
      )}
    </>
  );
}
function SourceEditor({
  t,
  record,
  mutate,
  busy,
  artifacts,
  documents,
  run,
  projectId,
  onSaved,
}) {
  const [spec, setSpec] = useState(() =>
      structuredClone(record?.spec || initial),
    ),
    [name, setName] = useState(record?.name || ""),
    [dirty, setDirty] = useState(false),
    [base, setBase] = useState(record);
  const update = (patch) => {
    setSpec((s) => ({ ...s, ...patch }));
    setDirty(true);
  };
  const section = (i, patch) =>
    update({
      sections: spec.sections.map((s, index) =>
        index === i ? { ...s, ...patch } : s,
      ),
    });
  return (
    <form
      className="panel"
      onSubmit={async (e) => {
        e.preventDefault();
        const r = await mutate(
          base ? "report.save" : "report.create",
          { name, spec },
          base,
        );
        if (r) {
          setBase(r.entity);
          setDirty(false);
          onSaved(r);
        }
      }}
    >
      <div className="record-head">
        <h2>{t("ต้นฉบับรายงาน", "Report source")}</h2>
        <Badge>
          {dirty
            ? t("ยังไม่บันทึก", "unsaved")
            : base
              ? `r${base.revision}`
              : t("ใหม่", "new")}
        </Badge>
      </div>
      <div className="form-grid">
        <Field label={t("ชื่อต้นฉบับ", "Source name")}>
          <input
            value={name}
            required
            onChange={(e) => {
              setName(e.target.value);
              setDirty(true);
            }}
          />
        </Field>
        <Field label={t("ชื่อเรื่องรายงาน", "Report title")}>
          <input
            value={spec.title}
            required
            onChange={(e) => update({ title: e.target.value })}
          />
        </Field>
        <Field label={t("ภาษา", "Language")}>
          <select
            value={spec.language}
            onChange={(e) => update({ language: e.target.value })}
          >
            <option value="th">ไทย</option>
            <option value="en">English</option>
          </select>
        </Field>
        <Field label={t("ฟอนต์", "Font available to engine")}>
          <input
            value={spec.fontFamily}
            required
            onChange={(e) => update({ fontFamily: e.target.value })}
          />
        </Field>
      </div>
      <details>
        <summary>{t("แม่แบบและรุ่น", "Template & version")}</summary>
        <div className="form-grid">
          <Field label="Template ID">
            <input
              value={spec.template?.id || ""}
              required
              onChange={(e) =>
                update({ template: { ...spec.template, id: e.target.value } })
              }
            />
          </Field>
          <Field label="Template version">
            <input
              value={spec.template?.version || ""}
              required
              onChange={(e) =>
                update({
                  template: {
                    ...spec.template,
                    version: Number(e.target.value),
                  },
                })
              }
            />
          </Field>
        </div>
      </details>
      {spec.sections.map((s, i) => (
        <fieldset className="report-section" key={i}>
          <legend>
            {t("ส่วนที่", "Section")} {i + 1}
          </legend>
          <Field label={t("หัวข้อ", "Heading")}>
            <input
              value={s.heading || ""}
              onChange={(e) => section(i, { heading: e.target.value })}
            />
          </Field>
          <Field label={t("เนื้อหา", "Text")}>
            <textarea
              value={s.text || ""}
              rows={4}
              onChange={(e) => section(i, { text: e.target.value })}
            />
          </Field>
          <details>
            <summary>
              {t(
                "ตารางและรูปภาพ",
                "Table and figure",
              )}
            </summary>
            <ReportTable t={t} table={s.table} onChange={table=>section(i,{table})}/>
            <Field label={t("Figure artifact ID", "Figure artifact ID")}>
              <select
                value={s.figure?.artifactId || ""}
                onChange={(e) =>
                  section(i, {
                    figure: e.target.value
                      ? {
                          artifactId: e.target.value,
                          revision: artifacts.find(
                            (a) => a.id === e.target.value,
                          )?.revision,
                        }
                      : undefined,
                  })
                }
              >
                <option value="">—</option>
                {artifacts.filter(a=>['png','jpg','jpeg'].includes(a.kind)).map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name || a.filename || a.id}
                  </option>
                ))}
              </select>
            </Field>
            {s.figure&&<><Field label={t('คำอธิบายรูป','Figure caption')}><input value={s.figure.caption??''} onChange={e=>section(i,{figure:{...s.figure,caption:e.target.value}})}/></Field><Field label={t('ความกว้างรูป (pt)','Figure width (pt)')}><input type="number" min="1" max="450" value={s.figure.width??360} onChange={e=>section(i,{figure:{...s.figure,width:Number(e.target.value)}})}/></Field></>}
            <label className="check"><input type="checkbox" checked={!!s.pageBreakBefore} onChange={e=>section(i,{pageBreakBefore:e.target.checked})}/>{t('ขึ้นหน้าใหม่ก่อนส่วนนี้','Start this section on a new page')}</label>
          </details>
          <button
            type="button"
            disabled={spec.sections.length === 1}
            onClick={() =>
              update({ sections: spec.sections.filter((_, n) => n !== i) })
            }
          >
            {t("ลบส่วนนี้", "Remove section")}
          </button>
        </fieldset>
      ))}
      <button
        type="button"
        onClick={() =>
          update({ sections: [...spec.sections, { heading: "", text: "" }] })
        }
      >
        {t("+ เพิ่มส่วน", "+ Add section")}
      </button>
      <Field
        label={t(
          "แหล่งอ้างอิงและหลักฐาน (บรรทัดละหนึ่งรายการ)",
          "Citations / evidence (one per line)",
        )}
      >
        <textarea
          value={spec.citations
            .map((c) =>
              typeof c === "string" ? c : c.text || c.url || JSON.stringify(c),
            )
            .join("\n")}
          onChange={(e) =>
            update({ citations: e.target.value.split("\n").filter(Boolean) })
          }
        />
      </Field>
      <Field
        label={t(
          "ไฟล์ผลลัพธ์ที่ใช้ประกอบ (กด Ctrl ค้างเพื่อเลือกหลายไฟล์)",
          "Input artifact revisions (Ctrl for multiple)",
        )}
      >
        <select
          multiple
          value={spec.inputs
            .filter((i) => i.artifactId)
            .map((i) => i.artifactId)}
          onChange={(e) =>
            update({
              inputs: Array.from(e.target.selectedOptions).map((o) => {
                const a = artifacts.find((a) => a.id === o.value);
                return {
                  artifactId: a.id,
                  revision: a.revision,
                  sha256: a.sha256,
                };
              }),
            })
          }
        >
          {artifacts.map((a) => (
            <option value={a.id} key={a.id}>
              {a.name || a.filename || a.id} · r{a.revision}
            </option>
          ))}
        </select>
      </Field>
      <NativeReportImport {...{t,documents,run,projectId,busy}} onImport={result=>update({sections:[...spec.sections,result.section],inputs:[...spec.inputs,result.input]})}/>
      <div className="actions">
        <Submit busy={busy}>{t("บันทึกต้นฉบับ", "Save report source")}</Submit>
        <small>
          {t(
            "การบันทึกต้นฉบับยังไม่ได้สร้างไฟล์ ต้องกด สร้าง DOCX และ PDF แยกอีกครั้ง",
            "Source save is separate from generation and delivery.",
          )}
        </small>
      </div>
    </form>
  );
}
function ReportTable({t,table,onChange}){
  const [text,setText]=useState(()=>table?.values.map(row=>row.join('\t')).join('\n')??'');
  return <><Field label={t('ข้อมูลตาราง (คัดลอกจากตารางมาวางได้เลย)','Table cells (paste rows with tab-separated columns)')}><textarea rows={4} value={text} placeholder={'Name\tValue\nรายการ\t10'} onChange={e=>{
    const value=e.target.value;setText(value);const rows=value.split('\n').map(row=>row.split('\t'));
    const valid=!value||(rows.length<=1000&&rows[0].length<=63&&rows.every(row=>row.length===rows[0].length));e.target.setCustomValidity(valid?'':t('ทุกแถวต้องมีจำนวนคอลัมน์เท่ากัน','Every row must have the same number of columns'));
    if(valid)onChange(value?{values:rows,header:table?.header!==false}:undefined);
  }}/></Field>{table&&<label className="check"><input type="checkbox" checked={table.header!==false} onChange={e=>onChange({...table,header:e.target.checked})}/>{t('แถวแรกเป็นหัวตาราง','Use first row as table header')}</label>}</>;
}
function NativeReportImport({t,documents,run,projectId,busy,onImport}){
  const [id,setId]=useState(''),[sheetId,setSheetId]=useState(''),[range,setRange]=useState('A1:B5'),[formulaMode,setFormulaMode]=useState('expressions'),[review,setReview]=useState(null);
  const document=documents.find(d=>d.id===id);
  return <details><summary>{t('นำเนื้อหาจากเอกสารหรือตารางใน FORGE','Import from Docs or a Sheets range')}</summary>
    <p className="help">{t('นำข้อความหรือเซลล์จากฉบับที่บันทึกไว้เข้ามา พร้อมที่มาและรหัสตรวจไฟล์ แต่จะไม่นำรูปแบบตัวอักษร ตารางในเอกสาร รูป หรือกราฟมาด้วย','Imports saved text or selected cells with revision and hash. Document styling, Docs tables, images and charts are not converted.')}</p>
    <Field label={t('เอกสารที่จะนำมา','Source document')}><select value={id} onChange={e=>{setId(e.target.value);setSheetId('');setReview(null);}}><option value="">—</option>{documents.map(d=><option key={d.id} value={d.id}>{d.name} · r{d.revision}</option>)}</select></Field>
    {document?.kind==='sheet'&&<div className="form-grid"><Field label={t('แผ่นงาน','Worksheet')}><select value={sheetId||document.snapshot.sheetOrder[0]} onChange={e=>{setSheetId(e.target.value);setReview(null);}}>{document.snapshot.sheetOrder.map(key=><option key={key} value={key}>{document.snapshot.sheets[key].name}</option>)}</select></Field><Field label={t('ช่วงเซลล์ (เช่น A1:C10)','Import range')}><input value={range} onChange={e=>{setRange(e.target.value);setReview(null);}}/></Field><Field label={t('เซลล์ที่มีสูตร','Report formulas')}><select value={formulaMode} onChange={e=>{setFormulaMode(e.target.value);setReview(null);}}><option value="expressions">{t('แสดงตัวสูตร เช่น =SUM(A1:A3)','Formula expressions as text')}</option><option value="cached-values">{t('แสดงผลลัพธ์ของสูตร','Use saved scalar values')}</option></select></Field></div>}
    <button type="button" disabled={busy||!document} onClick={()=>run(async()=>{const result=await request('/api/reports/extract-document',{projectId,documentId:id,expectedRevision:document.revision,sheetId:sheetId||undefined,range,formulaMode});setReview(result);return result;})}>{t('ดูตัวอย่างก่อนนำเข้า','Preview import')}</button>
    {review&&<div className="panel"><h3>{review.section.heading}</h3>{review.section.text&&<p style={{whiteSpace:'pre-wrap'}}>{review.section.text}</p>}{review.section.table&&<div className="table-wrap"><table><tbody>{review.section.table.values.map((row,i)=><tr key={i}>{row.map((cell,n)=><td key={n}>{String(cell)}</td>)}</tr>)}</tbody></table></div>}<small>r{review.input.revision} · {review.input.sourceSha256.slice(0,12)}</small><p className="help">{review.warnings.join(' ')}</p><button type="button" onClick={()=>{onImport(review);setReview(null);}}>{t('เพิ่มเนื้อหานี้ลงต้นฉบับรายงาน','Add this content to report source')}</button></div>}
  </details>;
}
function ReportJob({ t, job, run, busy, artifacts, setPreview }) {
  const outputs = artifacts.filter(
    (a) =>
      a.jobId === job.id ||
      (job.artifactIds || []).includes(a.id) ||
      (job.outputs || []).some((o) => o.artifactId === a.id),
  );
  const [details, setDetails] = useState(null);
  return (
    <article className="run">
      <div className="record-head">
        <strong>{job.id}</strong>
        <Badge>{job.status}</Badge>
      </div>
      <p>
        {date(job.createdAt)} · {t("ต้นฉบับฉบับที่", "Source revision")}{" "}
        {job.sourceRevision ?? job.reportRevision ?? "—"}
      </p>
      {job.error && (
        <p className="error-text">
          {typeof job.error === "string" ? job.error : job.error.message}
        </p>
      )}
      <div className="actions">
        <button
          onClick={() =>
            run(async () => {
              const r = await request(
                `/api/reports/jobs/${encodeURIComponent(job.id)}`,
              );
              setDetails(r);
              return r;
            })
          }
        >
          {t("ดูสถานะและบันทึกการทำงาน", "Inspect status / logs")}
        </button>
        <button
          disabled={busy}
          onClick={() =>
            run(() =>
              request(`/api/reports/jobs/${encodeURIComponent(job.id)}/stop`, {
                operationId: operationId(),
              }),
            )
          }
        >
          <Square size={14} />
          {t("หยุดงานนี้", "Request job stop")}
        </button>
        {outputs.map((a) => (
          <React.Fragment key={a.id}>
            <a className="button" href={downloadUrl(a.id)} download>
              <Download size={14} />
              {a.name || a.filename || a.kind || "file"}
            </a>
            {/pdf/i.test(
              a.contentType || a.filename || a.name || a.kind || "",
            ) && (
              <button onClick={() => setPreview(a)}>
                {t("ดู PDF", "Preview PDF")}
              </button>
            )}
          </React.Fragment>
        ))}
      </div>
      {details && (
        <details open>
          <summary>{t("รายละเอียดทางเทคนิค", "Service result")}</summary>
          <Json value={details} />
        </details>
      )}
    </article>
  );
}
function EngineSettings({ t, run, busy, onHealth, health }) {
  return (
    <form
      className="panel"
      onSubmit={(e) => {
        e.preventDefault();
        const d = new FormData(e.currentTarget);
        run(async () => {
          const r = await request("/api/reports/configure", {
            ...(d.get("wordcraftPath")
              ? { wordcraft: { path: d.get("wordcraftPath") } }
              : {}),
            ...(d.get("pdfcraftPath")
              ? { pdfcraft: { path: d.get("pdfcraftPath") } }
              : {}),
            fonts: [
              {
                family: d.get("fontFamily"),
                version: d.get("fontVersion"),
                paths: d
                  .get("fontPaths")
                  .split("\n")
                  .map((p) => p.trim())
                  .filter(Boolean),
                license: "local system font; not redistributed",
              },
            ],
          });
          onHealth(await request("/api/reports/health"));
          return r;
        });
      }}
    >
      <h2>{t("โปรแกรมสร้างไฟล์บนเครื่องนี้", "Machine-local engines")}</h2>
      <div className="actions">
        {["wordcraft", "pdfcraft"].map((engine) => (
          <React.Fragment key={engine}>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                run(async () => {
                  const h = await request("/api/reports/configure", {
                    action: "discover",
                    engine,
                  });
                  onHealth(h);
                  return h;
                })
              }
            >
              {t("ค้นหาในเครื่อง", "Discover")} {engine}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                run(async () => {
                  const h = await request("/api/reports/configure", {
                    action: "install",
                    engine,
                  });
                  onHealth(h);
                  return h;
                })
              }
            >
              {t("ติดตั้งรุ่นที่รองรับ", "Install verified release")} {engine}
            </button>
          </React.Fragment>
        ))}
      </div>
      <div className="form-grid">
        <Field label="WordCraft executable">
          <input name="wordcraftPath" defaultValue={health?.config?.wordcraft?.path ?? ''} />
        </Field>
        <Field label="PdfCraft executable">
          <input name="pdfcraftPath" defaultValue={health?.config?.pdfcraft?.path ?? ''} />
        </Field>
        <Field label={t("ชื่อรุ่นของชุดฟอนต์", "Font profile version label")}>
          <input required name="fontVersion" defaultValue={health?.config?.fonts?.[0]?.version ?? 'system-local'} />
        </Field>
        <Field label={t("ฟอนต์", "Font family")}>
          <input required name="fontFamily" list="report-font-families" defaultValue={health?.config?.fonts?.[0]?.family ?? 'Tahoma'} />
          <datalist id="report-font-families">{(health?.engines?.wordcraft?.fonts?.families??[]).map(f=><option key={f} value={f}/>)}</datalist>
        </Field>
        <Field
          label={t(
            "ไฟล์ฟอนต์ในเครื่อง (บรรทัดละหนึ่งไฟล์)",
            "Local font files (one path per line)",
          )}
        >
          <textarea name="fontPaths" rows={2} defaultValue={(health?.config?.fonts?.[0]?.files??[]).map(f=>f.path).join('\n')} />
        </Field>
      </div>
      <p className="help">
        {t(
          "ที่อยู่ไฟล์ใช้ได้เฉพาะเครื่องนี้ ระบบจะตรวจโปรแกรมก่อนใช้งานทุกครั้ง",
          "Paths are machine-local. The service verifies actual binaries and readiness before execution.",
        )}
      </p>
      <Submit busy={busy}>
        {t("บันทึกและตรวจโปรแกรม", "Save & inspect engines")}
      </Submit>
    </form>
  );
}
