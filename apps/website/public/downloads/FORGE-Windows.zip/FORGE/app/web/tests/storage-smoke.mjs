import {browserOwner} from '../../../tests/support/browser-owner.mjs';
// Real local filesystem GUI backup/restore; Drive account qualification is separate.
import assert from 'node:assert/strict';
import {mkdtemp,writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {chromium} from 'playwright';
import {chooseTheme, openRoute, openThemePicker, setLanguage} from '../../../tests/support/app-shell.mjs';
import {createApplication} from '../../server/main.mjs';
const temp=await mkdtemp(path.join(os.tmpdir(),'forge-storage-gui-')),app=await createApplication({dataDir:path.join(temp,'state')});
const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.setDefaultTimeout(15000);page.on('pageerror',e=>errors.push(e.message));
const state=async()=>(await page.request.get(app.url+'/api/state')).json(),button=name=>page.getByRole('button',{name,exact:true});
async function wait(predicate){for(let i=0;i<100;i++){const value=await state();if(predicate(value))return value;await page.waitForTimeout(100);}throw Error('Storage state timeout');}
async function action(name,suffix){const pending=page.waitForResponse(r=>r.url().endsWith(suffix)&&r.request().method()==='POST');await button(name).click();const response=await pending;assert.equal(response.status(),200);const result=await response.json();assert.equal(result.status,'completed',JSON.stringify(result.error));return result;}
try{
  await page.goto(app.url+'/app');await setLanguage(page,'en');await button('Create first project').click();await page.getByLabel('Project name',{exact:true}).fill('Disposable storage GUI fixture');await page.getByLabel('Workspace directory').fill(path.join(temp,'workspace'));await page.getByRole('dialog').getByRole('button',{name:'Create project',exact:true}).click();await wait(s=>s.projects.length===1);
  await openRoute(page,'Artifacts');const content='สวัสดี FORGE · registered artifact bytes';await page.getByLabel('Upload a file (up to 16 MB)',{exact:true}).setInputFiles({name:'ไทย.txt',mimeType:'text/plain',buffer:Buffer.from(content)});await button('Upload & verify').click();let s=await wait(s=>s.artifacts.length===1);const original=s.artifacts[0],projectId=s.projects[0].id;
  const doc=await page.request.post(app.url+'/api/command',{headers:await browserOwner(app.url),data:{type:'document.create',projectId,operationId:crypto.randomUUID(),data:{name:'Native document with durable resource',kind:'doc',snapshot:{body:{dataStream:'Saved native content\r\n'},resource:'/api/artifacts/'+original.id+'/download'}}}});assert.equal(doc.status(),200);
  await openRoute(page,'Storage & recovery');await button('+ Local folder').click();await page.getByLabel('Destination name',{exact:true}).fill('Verified local archive');await page.getByLabel('Archive directory (outside workspace)',{exact:true}).fill(path.join(temp,'archive'));await page.getByLabel('Revisions to retain',{exact:true}).fill('1');await button('Save destinations & routing').click();await wait(s=>s.projects[0].profile.storage.destinations?.length===1);
  await button('Check destination').click();await page.getByRole('status').filter({hasText:'ready'}).waitFor();
  const first=await action('Back up project & registered files','/api/storage/bundles/backup');
  const second=await action('Back up project & registered files','/api/storage/bundles/backup');assert.notEqual(first.bundleId,second.bundleId);
  await button('Inspect destination revisions').click();await page.getByLabel('Select complete project backup',{exact:true}).selectOption(second.bundleId);await page.getByLabel('New restore directory (must not exist)',{exact:true}).fill(path.join(temp,'restored'));
  const restored=await action('Verify & restore into new project','/api/storage/bundles/restore');s=await wait(s=>s.projects.length===2);const artifact=s.artifacts.find(a=>a.projectId===restored.restoredProjectId);assert.ok(artifact);assert.notEqual(artifact.id,original.id);assert.equal(artifact.sha256,original.sha256);assert.equal(artifact.jobId,undefined);
  const bytes=await page.request.get(app.url+'/api/artifacts/'+artifact.id+'/download');assert.equal(bytes.status(),200);assert.equal(await bytes.text(),content);
  const native=s.documents.find(d=>d.projectId===restored.restoredProjectId);assert.equal(native.snapshot.body.dataStream,'Saved native content\r\n');assert.equal(native.snapshot.resource,'/api/artifacts/'+artifact.id+'/download');
  const preview=await action('Preview older bundles to remove','/api/storage/retention');assert.ok(preview.candidates.includes(first.bundleId));assert.ok(!preview.candidates.includes(second.bundleId));
  await page.screenshot({path:path.join(temp,'storage-desktop.png'),fullPage:true});for(const width of [320,375,768]){await page.setViewportSize({width,height:1000});assert.equal(await page.locator('html').evaluate(e=>e.scrollWidth<=innerWidth),true,'Storage overflow '+width);}await page.screenshot({path:path.join(temp,'storage-mobile.png'),fullPage:true});assert.deepEqual(errors,[]);
  const evidence={result:'PASSED',fixtureDir:temp,scope:'actual local filesystem; Drive live NOT_RUN',checks:['GUI file upload','destination configuration and health','two verified full project backups','explicit selected manifest restore into new project/folder','hash-identical restored bytes downloaded','native resource IDs remapped','retention preview protects newest full backup','320/375/768 responsive','no browser exceptions'],backupJobs:[first.id,second.id],restoreJob:restored.id,restoredProjectId:restored.restoredProjectId};await writeFile(path.join(temp,'evidence.json'),JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence,null,2));
}catch(error){await page.screenshot({path:path.join(temp,'failure.png'),fullPage:true}).catch(()=>{});console.error('FIXTURE_DIR',temp);throw error;}finally{await browser.close();await app.close();}
