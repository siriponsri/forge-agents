FORGE 1.1.0-alpha.3 — alpha

Extract the entire FORGE folder. Install Node.js 24.13+ from https://nodejs.org.
Open Start-FORGE.command; Stop/Restart launchers are included.
First start installs pinned dependencies and builds the local workbench.
Projects/settings are saved in machine application data, separate from this source.

IMPLEMENTATION_INCOMPLETE / HOME_UAT_NOT_RUN
macOS launchers are included; actual macOS qualification is NOT_RUN.
Native report-engine packages are currently qualified only on Windows x64.
Read docs/FORGE_LOCAL_QUICKSTART_TH.md and release-info.json before use.
Source commit: 77e6ac08a21096e934279742d4ec0eaf35ccbe6e
